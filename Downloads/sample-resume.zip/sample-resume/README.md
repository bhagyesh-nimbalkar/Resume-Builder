# Sample Resume

A Pen created on CodePen.io. Original URL: [https://codepen.io/knaman2609/pen/Zbyjvv](https://codepen.io/knaman2609/pen/Zbyjvv).

inspired from represent.io